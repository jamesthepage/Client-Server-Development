# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'Yoloswag1' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            try:
                self.database.animals.insert_one(data)  # data should be dictionary        
                return True #return true when record is successfully inserted
            except Exception as e:
                print("Create operation failed:", e) #error message if failed insertion
                return False
        else: 
            raise Exception("Nothing to save, because data parameter is empty") #no data provided

    # Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            try:
                cursor = self.database.animals.find(data) #search animals collection using provided criteria
                
                return list(cursor) #convert MongoDB cursor into a list of records
            
            except Exception as e:
                print("Read operation failed:", e) #error message if failed search
                return []
        else:
            raise Exception("Nothing to search, because data parameter is empty") #no search criteria provided, therefore, a message stating so
    
    def update(self, data, updates):
        if data is not None and updates is not None:
            try:
                result = self.database.animals.update_many(data, updates)
                return result.modified_count #Return number of documents that were modified
            except Exception as e:
                print("Update operation failed:", e)
                return 0
        else:
            raise Exception("Nothing to update, because data or updates parameter is empty")
            
    def delete(self, data):
        if data is not None:
            try:
                result = self.database.animals.delete_many(data)
                return result.deleted_count #Return number of documents that were delete
            except Exception as e:
                print("Delete operation failed:", e)
                return 0
        else:
            raise Exception("Nothing to delete, because data parameter is empty")